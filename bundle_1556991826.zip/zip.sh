rm -rf bundle_*.zip
zip -r "bundle_$(date +%s).zip" *
