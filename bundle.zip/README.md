# Social Directory

## Structure

### Entry Point
Actually execute our target job.

[index.js](./index.js)

### Clients
Manage integrations to 3rd part api's.

- [Google Calendar](./clients/google/calendar)
- [Google Sheets](./clients/google/sheets)
- [Google Mail](./clients/google/mail)

## TODO
- move secrets somewhere and push repo up to github