const { handler } = require('./index.js');

handler();
