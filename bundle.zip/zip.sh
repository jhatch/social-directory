zip -r bundle.zip *
